/*#include <iostream>

using namespace std;

void draw(char c) {
    // The function to draw the letter 'C' using the character provided by the user
    for (int i = 0; i <= 8; i++) {
        if (i == 0 || i == 8) {
            // Print the first and last row with three instances of the character
            cout << "  " << c << " " << c << " " << c << endl;
        } else if (i == 1 || i == 7) {
            // Print the second and seventh row with the character surrounded by spaces
            cout << " " << c << "    " << c << endl;
        } else {
            // Print the remaining rows with the character only
            cout << c << endl;
        }
    }
}

int main() {
    char c;
    char condition;
    bool quit = false;

    cout << "************C Letter Drawing Program************" << endl;

    while (!quit){

        // Prompt the user to enter the character they want to draw 'C' with
        cout << "\nEnter the character you want to draw 'C' with: ";
        cin >> c;
        draw(c);

        cout << "Do you want to repeat the calculations (y | n): ";
        cin >> condition;

        if (condition == 'n' || condition == 'N'){
            quit = true;

        }else{
            quit = false;
        }

    }

    cout << "\nSee you later :)" << endl;

    return 0;
}
*/
