#include <iostream>
#include <iomanip>
#include <limits>

using namespace std;

void temp (float start_temp, float end_temp)
{
    for(int Tc = start_temp; Tc <= end_temp; Tc++){
        // Calculate the velocity of sound based on the temperature
        float velocity = 331.3 + 0.61 * Tc;
        cout << "At " << Tc << " degrees Celsius the velocity of sound is " << fixed << setprecision(1) << velocity << " m/s" << endl;
    }
}

int main ()
{
    float start_temp, end_temp;
    char condition;
    bool quit = false;

    cout << "************Velocity according to Temperature program************" << endl;

    while (!quit){

        // Get the starting temperature
        cout << "\nEnter the Starting Temperature: ";
        cin >> start_temp;

        // Get the ending temperature
        cout << "\nEnter the Ending Temperature: ";
        cin >> end_temp;

        cout << endl;

        temp(start_temp,end_temp);

        cout << "\nDo you want to repeat the calculations (y | n): ";
        cin >> condition;

        if (condition == 'n' || condition == 'N'){
            quit = true;

        }else{
            quit = false;
        }

    }

    cout << "\nSee you later :)" << endl;

    return 0;
}
