#include <iostream>
#include <cmath>
using namespace std;

// Function to check if a number is a perfect square
bool isPerfectSquare(int num)
{
    int sqr = sqrt(num);
    return (sqr * sqr == num);
}

// Function to reverse the digits of a number
int reverseDigit(int num)
{
    int revdig = 0;
    while (num > 0)
    {
        revdig = revdig * 10 + num % 10;
        num = num / 10;
    }
    return revdig;
}

// Function to calculate the sum of all digits in a number
int calcsum(int num)
{
    int sum = 0;
    int rem;
    while (num > 0)
    {
        rem = num % 10;
        sum += rem;
        num /= 10;
    }
    return sum;
}

int main()
{
    int num;
    int oper = -1;

    // Loop until the user want to exit
    while (oper)
    {
        // User choose the operation he/she wants or to exit
        cout << "Enter operation you want\n1) Is perfect square\n2) Reverse digit\n3) Sum of all digits\n0) Exit\n";
        cin >> oper;

        if (oper == 0)
        {
            // Exit the loop
            break;
        }

        //User input a number
        cout << "Enter number:\n";
        cin >> num;

        if (oper == 1)
        {
            // Check if the number is a perfect square
            if (isPerfectSquare(num))
            {
                cout << "It's a perfect square number\n";
            }
            else
            {
                cout << "It's not a perfect square number\n";
            }
        }
        else if (oper == 2)
        {
            // Reverse the digits of the number
            cout << "The reverse digit is: " << reverseDigit(num) << "\n";
        }
        else if (oper == 3)
        {
            // Calculate the sum of all digits in the number
            cout << "The sum of all digits is: " << calcsum(num) << "\n";
        }
        else if (oper != 0)
        {
            cout << "Enter a valid operation\n";
        }
    }

    return 0;
}
