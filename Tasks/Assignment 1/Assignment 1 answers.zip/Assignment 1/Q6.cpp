#include <iostream>

using namespace std;

const double LPG = 0.264179;

double MilesPerGallon(double liters, double miles) {
    // Calculate miles per gallon
    double gallons = liters * LPG;                       // to calc miles/gallon first we need to calc number of gallons in the car by multiplying number of liters by the LPG
    double miles_per_gallon = miles / gallons;             // then miles/gallon is calc by dividing the total number of miles traveled by the number of gallons of gas in the car
    return miles_per_gallon;
}

int main(){

    cout << "************Miles Per Gallon Calculator************\n" << endl;

    double liters;
    double miles;
    double miles_per_gallon;     // miles per gallon

    char condition;
    bool quit = false;

    while (!quit){

        cout << "Enter number of liters: ";
        cin >> liters;

        cout << "Enter total number of miles traveled by the car: ";
        cin >> miles;

        miles_per_gallon = MilesPerGallon(liters, miles);
        cout << "Number of miles per gallon: " << miles_per_gallon << endl;

        cout << "Do you want to repeat the calculations (y | n): ";
        cin >> condition;

        if (condition == 'n' || condition == 'N'){
            quit = true;

        }else{
            quit = false;
        }

    }

    return 0;
}
