#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int bal;
    double intrest, total, minpay;
    int oper = -1;

    // Loop until user don't want to
    while (oper)
    {
        cout << "\nEnter balance\n";
        cin >> bal; // User entering the balance

        // Calculate interest based on balance
        if (bal > 1000)
        {
            intrest = (bal - 1000) * 0.01 + (1000 * 0.015);
        }
        else
        {
            intrest = bal * 0.015;
        }

        // Calculate total amount (balance + interest)
        total = bal + intrest;

        // Calculate minimum payment
        if (total > 10)
        {
            if (total * 0.1 > 10)
            {
                minpay = total * 0.1;
            }
            else
            {
                minpay = 10;
            }
        }
        else
        {
            minpay = total;
        }

        // Display the results
        cout << "Interest on balance: " << intrest << "\nTotal amount: " << total << "\nMinpayment: " << minpay;
        // Ask if user want to calculate again or to exit
        cout << "\nTo exit, press 0. To calculate again, press any other number: ";
        cin >> oper;
    }

    return 0;
}
