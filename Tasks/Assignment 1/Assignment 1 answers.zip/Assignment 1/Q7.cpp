#include <iostream>
#include <cmath>

using namespace std;

const double G = 6.673 * pow(10, -8);

double GravitationalForce(double mass1, double mass2, double distance){                    // this function calculates the gf using the mass of two bodies and the distance between them

    double force = (G*mass1*mass2) / pow(distance, 2);
    return force;

}

int main(){

    cout << "**************Gravitational Force Calculator Program**************\n" << endl;

    // initializing properties of the formula
    double mass1, mass2;
    double distance;
    double result;

    // controlling the program
    char condition;
    bool quit = false;

    while(!quit){

        cout << "Enter the mass of the first body: ";
        cin >> mass1;

        cout << "Enter the mass of the second body: ";
        cin >> mass2;

        cout << "Enter the distance between two bodies: ";
        cin >> distance;

        result = GravitationalForce(mass1, mass2, distance);
        cout << "Gravitational Force = " << result << endl;

        cout << "Do you want to repeat the calculations: (y|n): ";
        cin >> condition;

        if(condition == 'n' || condition == 'N'){
            quit = true;
        }else if(condition == 'y' || condition == 'Y'){
            quit = false;
        }else{
            break;
        }
    }



    return 0;
}
