#include <iostream>
#include<cmath>

using namespace std;
//Bonus A
//#define INCHES 0.393701
#define PI 22/7
/*float CmtoInches(float diameter_cm){
    return diameter_cm*INCHES;
}*/

float AreaInSquareInches(float radius){
    return PI*pow(radius,2); // here we calculate the area of the pizza
}

float PricePerInches(float price , float AreaInches){
    if(AreaInches==0)
        return 0; // we return 0 to avoid divide by 0
    return price / AreaInches; // we return the price per inches
}

string WhichIsBetter(float small_ppi , float large_ppi){

    if(small_ppi<=large_ppi) // incase less or equal to the small pizza is better
        return "Small Pizza";
    return "Large Pizza"; // incase not so we will pass the if condition the large pizza is better

    // note : the function stops at the first return so we do not need to define else as if it go through
    // the if so will stop if not will complete until face the other return
}

float CalPPI(float price , float diameter){
    float area = AreaInSquareInches(diameter/2); // calculate the area using the function we define
    float ppi = PricePerInches(price,area); // calculate the price per square inches
    return ppi; // here return the price per square inches
    //return PricePerInches(price,AreaInSquareInches(diameter/2));
    // the result will be the same if we use any of them
}

int main()
{
    float small_price ,large_price , small_diameter_cm , large_diameter_cm,small_ppi,large_ppi;
    cout<<"Enter the price of the small and large pizza respectively : ";
    cin>>small_price>>large_price;
    cout<<"Enter the diameter of the small and large pizza respectively : ";
    cin>>small_diameter_cm>>large_diameter_cm;
    small_ppi = CalPPI(small_price,small_diameter_cm);
    large_ppi = CalPPI(large_price,large_diameter_cm);
    cout<<"The Price Per Inches for Small Pizza is : "<<small_ppi<<
    " Price Per Inches\nThe Price Per Inches for Large Pizza is : "<<large_ppi<<" Price Per Inches"<<endl;
    string better = WhichIsBetter(small_ppi,large_ppi);
    cout<<"Its better to buy : "<<better<<endl;

    return 0;
}
