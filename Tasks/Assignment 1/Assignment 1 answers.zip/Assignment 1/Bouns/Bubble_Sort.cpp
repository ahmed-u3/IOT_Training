#include <iostream>
using namespace std;

// here we define the function using two ways
// 1st use define , 2nd using the normal function definition
#define SWAP(a,b) a = a^b;\
                  b = a^b;\
                  a = a^b;

// Example
// a = 1 0 1 0 1 , b = 0 1 1 0 1
// a = a ^ b = 1 0 1 0 1 ^ 0 1 1 0 1 = 1 1 0 0 0
// b = a ^ b = 1 1 0 0 0 ^ 0 1 1 0 1 = 1 0 1 0 1
// a = a ^ b = 1 1 0 0 0 ^ 1 0 1 0 1 = 0 1 1 0 1

// 1st swap function using +
void swap_func_1(int& a , int& b){
    a = a + b; // 10 + 5 = 15
    b = a - b; // 15 - 5 = 10
    a = a - b; // 15 - 10 = 5
}

// 2nd swap function using xor and it the same the as define above using #define
void swap_func_2(int& a , int& b){
    a = a ^ b; // 1 0 1 0 1 ^ 0 1 1 0 1 = 1 1 0 0 0
    b = a ^ b; // 1 1 0 0 0 ^ 0 1 1 0 1 = 1 0 1 0 1
    a = a ^ b; // 1 1 0 0 0 ^ 1 0 1 0 1 = 0 1 1 0 1
}

// 1st version bubble sort
// we define the normal bubble sort using two loops and flag to break as if there is no swap through the first iteration
// so this mean the array is already sorted , we use the goto statement to return in case the array is sorted
void bubble_sort(int arr[],int length){
    bool flag = true; // flag for breaking the loops in case array is sorted

    for(int i = 0 ;i<length;i++){ // 1st for loop to move through the array n times depends , n is the length of array
        for(int j = 0 ;j<length-i-1;j++){
        // 2nd for loop is to swap elements of array , every iteration is decreased by one as it not need to check bec sure it is in its right place
        // we are sure at end of each iteration the bigger element is swapped to end of the array
            if(arr[j]>arr[j+1]){ // condition of swapping , we swap in case if greater that only
                SWAP(arr[j],arr[j+1]);
        // here we swap by reference , we do not need to put &(address of operator) bec the array or array element is passed by reference
                flag = false; // assign the flag to false to avoid breaking the for loop bec it is not sorted
            }
        }
        if(flag) // condition to exist outer for loop if the array is sorted
            goto loop_end; // take us to loop_end to break
    }
    loop_end: // definition of label to help while using goto statement
        return;
}

// 2nd version bubble sort using pointers
void bubble_sort_ptr(int arr[],int length){
    bool flag = true;// flag for breaking the loops in case array is sorted
    int* ptr = arr;
    // here we assign the address of array to pointer , arr == &arr[0] bec the array has the address of the first element so it will be the same
    for(int i = 0 ;i<length;i++){ // 1st for loop to move through the array n times depends , n is the length of array
        for(int j = 0 ;j<length-i-1;j++){
        // 2nd for loop is to swap elements of array , every iteration is decreased by one as it not need to check bec sure it is in its right place
        // we are sure at end of each iteration the bigger element is swapped to end of the array
        // imagine the address of 1st element is 1000 , then the second is 1004 in case of integer array
            if(*(ptr+j)>*(ptr+j+1)){
                // condition of swapping , we swap in case if greater that only , we use (*) dereference operator to get the value at this address
                swap_func_2(*(ptr+j),*(ptr+j+1));
        // here we swap by reference , we do not need to put &(address of operator) bec the array or array element is passed by reference
        // we already pass pointers
                flag = false;// assign the flag to false to avoid breaking the for loop bec it is not sorted
            }
        }
        if(flag)// condition to exist outer for loop if the array is sorted
            goto loop_end; // take us to loop_end to break
    }
    loop_end:// definition of label to help while using goto statement
        return;
}

// 3rd version using recursion
void bubble_sort_rec(int arr[],int length){
    if(length==1) // the base condition of recursion
        return;

    for(int i = 0;i<length-1;i++){// we only 1 for loop to swap while the recursion will loop in array n times
        if(arr[i]>arr[i+1]){
        // here we swap by reference , we do not need to put &(address of operator) bec the array or array element is passed by reference
            swap_func_1(arr[i],arr[i+1]);
        // here we swap by reference , we do not need to put &(address of operator) bec the array or array element is passed by reference
        }
    }
    // we call it again to go through the array
    bubble_sort_rec(arr,length-1);
}

// function to print the array to avoid redundance
void toString(int arr [],int length){
    for(int i = 0;i<length;i++){
        cout<<arr[i]<<"  ";
    }
    LINE;
}

// function to print before and after sorting and choose the sorting techique we need
// by default it use the normal bubble sort
void print_before_after(int arr[],int length,int b_sort=0){
    cout<<"The length of the array is : "<<length<<endl;
    cout<<"The array before soring : ";
    toString(arr,length);
    //LINE;
    if(b_sort==1)
        bubble_sort_ptr(arr,length);
    else if(b_sort==2)
        bubble_sort_rec(arr,length);
    else
        bubble_sort(arr,length);
    cout<<"The array after soring : ";
    toString(arr,length);
    LINE;
}
int main()
{
    N_ID;
    LINE;
    int arr_1[] = {60,50,40,30,20,10,0};
    int arr_2[] = {10,5,2,3,6,1,0,4,7,9,8};
    int arr_3[] = {90,80,70,60,10,50,40,30,20,0};
    int arr_4[] = {1,2,3,4,5,6,7,8,9};
    int length= sizeof(arr_1)/sizeof(arr_1[0]);
    print_before_after(arr_1,length);

    length= sizeof(arr_2)/sizeof(arr_2[0],1);
    print_before_after(arr_2,length);

    length= sizeof(arr_3)/sizeof(arr_3[0],2);
    print_before_after(arr_3,length);

    length= sizeof(arr_4)/sizeof(arr_4[0]);
    print_before_after(arr_4,length,43243);// will not matter bec the else condition so it will use the normal bubble sort

    return 0;
}
