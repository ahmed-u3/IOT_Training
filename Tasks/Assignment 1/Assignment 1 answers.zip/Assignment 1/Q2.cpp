#include <iostream>

using namespace std;

int main() {
    double time; // time (input from user)
    int acceleration =32; // constant in feets
    cout << "please enter time in seconds : ";
    cin >> time;
    double distance = (time*time*acceleration)/2; // rule to calculate the distance in feet
    cout << "the distance = : " << (distance);


    return 0;
}
